<?php  get_header(); ?>

<!--Main layout-->
    <main>
        <section class="indigo grey lighten-2">
            <div class="container">
                
            </div>
        </section>

        <section>
            <div class="container">

            </div>
        </section>

        <section>
            <div class="container">
                
            </div>
        </section>

    </main>
    <!--Main layout-->

<?php  get_footer(); ?>

<?php  get_header();?>

<!--Main layout-->
  
      
            <div class="container">
                <header class="header">
                    <div class="search-header">
                        <?php get_search_form(); ?>
                <h1 class="font-weight-bold">Results...</h1>
            </div>
    
    <!--Main layout-->
